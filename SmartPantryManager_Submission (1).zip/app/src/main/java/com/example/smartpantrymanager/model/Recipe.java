package com.example.smartpantrymanager.model;

public class Recipe {
    public int id;
    public String name;
    public String ingredients;
    public String method;

    public Recipe(int id, String name, String ingredients, String method) {
        this.id = id;
        this.name = name;
        this.ingredients = ingredients;
        this.method = method;
    }
}
