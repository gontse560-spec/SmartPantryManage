package com.example.smartpantrymanager;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.smartpantrymanager.adapter.RecipeAdapter;
import com.example.smartpantrymanager.data.DatabaseHelper;
import com.example.smartpantrymanager.model.Recipe;
import java.util.ArrayList;

public class SuggestedRecipesActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);setContentView(R.layout.activity_suggestions);DatabaseHelper db=new DatabaseHelper(this);
        RecyclerView rv=findViewById(R.id.recyclerRecipes);TextView info=findViewById(R.id.txtSuggestionInfo);rv.setLayoutManager(new LinearLayoutManager(this));
        ArrayList<Recipe> recipes=db.getStrictMatches();
        if(recipes.isEmpty())info.setText("No recipes match your pantry yet - add more ingredients.");
        else info.setText(recipes.size()+" recipe(s) can be made with your current pantry.");
        rv.setAdapter(new RecipeAdapter(recipes,r->{Intent i=new Intent(this,RecipeDetailActivity.class);i.putExtra("recipeId",r.id);startActivity(i);}));
        findViewById(R.id.btnBack).setOnClickListener(v->finish());
    }
}
