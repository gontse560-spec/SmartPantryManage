package com.example.smartpantrymanager;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.smartpantrymanager.data.DatabaseHelper;
import com.example.smartpantrymanager.model.Recipe;

public class RecipeDetailActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);setContentView(R.layout.activity_recipe_detail);
        DatabaseHelper db=new DatabaseHelper(this);Recipe r=db.getRecipe(getIntent().getIntExtra("recipeId",-1));
        if(r!=null){((TextView)findViewById(R.id.txtRecipeTitle)).setText(r.name);
            ((TextView)findViewById(R.id.txtIngredients)).setText(formatIngredients(r.ingredients));
            ((TextView)findViewById(R.id.txtMethod)).setText(r.method);}
        findViewById(R.id.btnDetailBack).setOnClickListener(v->finish());
    }
    private String formatIngredients(String s){StringBuilder x=new StringBuilder();for(String a:s.split(","))x.append("• ").append(a.replace(":", ": ")).append("\n");return x.toString();}
}
