package com.example.smartpantrymanager.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.smartpantrymanager.model.PantryItem;
import com.example.smartpantrymanager.model.Recipe;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "smart_pantry.db";
    private static final int DB_VERSION = 1;

    public DatabaseHelper(Context context) { super(context, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE pantry (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, quantity REAL NOT NULL, unit TEXT NOT NULL, expiry TEXT)");
        db.execSQL("CREATE TABLE recipes (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, ingredients TEXT NOT NULL, method TEXT NOT NULL)");
        seedRecipes(db);
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}

    private void seedRecipes(SQLiteDatabase db) {
        String[][] data = {
            {"Tomato Omelette","egg:2,tomato:2,onion:1","Whisk eggs. Fry onion and tomato. Add eggs and cook until set."},
            {"Chicken Rice","chicken:250,rice:200,onion:1,carrot:1","Cook rice. Fry chicken and vegetables, then combine with rice."},
            {"Vegetable Pasta","pasta:200,tomato:2,onion:1,garlic:1","Boil pasta. Cook vegetables with garlic and tomato, then mix."},
            {"Chicken Sandwich","bread:2,chicken:150,tomato:1,lettuce:1","Cook chicken. Layer chicken, tomato and lettuce between bread slices."},
            {"Tuna Pasta","pasta:200,tuna:1,tomato:2,onion:1","Cook pasta. Fry onion and tomato, add tuna, then combine."},
            {"Beef Stir Fry","beef:250,pepper:1,onion:1,carrot:1,soy sauce:1","Slice ingredients. Stir-fry beef, then vegetables and soy sauce."},
            {"Pancakes","flour:200,milk:250,egg:2,sugar:30","Mix ingredients into batter. Cook small portions in a hot pan."},
            {"French Toast","bread:2,egg:2,milk:100,sugar:10","Whisk egg, milk and sugar. Dip bread and fry both sides."},
            {"Chicken Salad","chicken:150,lettuce:1,tomato:1,cucumber:1","Cook chicken. Chop vegetables and toss everything together."},
            {"Egg Fried Rice","rice:200,egg:2,onion:1,carrot:1,soy sauce:1","Fry onion and carrot. Add rice and egg, then season with soy sauce."},
            {"Cheese Toast","bread:2,cheese:2,butter:10","Butter bread, add cheese and toast until golden."},
            {"Tomato Soup","tomato:4,onion:1,garlic:1,stock:1","Cook onion and garlic. Add tomato and stock, simmer and blend."},
            {"Beef Pasta","beef:200,pasta:200,tomato:2,onion:1,garlic:1","Cook pasta. Brown beef with vegetables and tomato, then combine."},
            {"Veggie Omelette","egg:3,pepper:1,onion:1,tomato:1,cheese:1","Beat eggs. Cook vegetables, add eggs and cheese, then fold."},
            {"Chicken Curry","chicken:250,onion:1,tomato:2,curry powder:10,rice:200","Cook onion and chicken. Add tomato and curry powder, simmer and serve with rice."},
            {"Garlic Bread","bread:2,butter:20,garlic:1","Mix garlic with butter. Spread on bread and bake until crisp."},
            {"Tuna Sandwich","bread:2,tuna:1,mayonnaise:20,lettuce:1","Mix tuna and mayonnaise. Add lettuce and fill the bread."},
            {"Vegetable Rice","rice:200,carrot:1,pepper:1,onion:1,peas:50","Cook vegetables. Add rice and stir until heated through."},
            {"Banana Pancakes","banana:2,egg:2,flour:150,milk:100","Mash banana and mix with remaining ingredients. Cook pancakes."},
            {"Mac and Cheese","pasta:200,cheese:3,milk:200,butter:20,flour:20","Cook pasta. Make a simple cheese sauce and combine with pasta."}
        };
        for (String[] r : data) {
            ContentValues v = new ContentValues();
            v.put("name", r[0]); v.put("ingredients", r[1]); v.put("method", r[2]);
            db.insert("recipes", null, v);
        }
    }

    public long addPantry(PantryItem item) {
        ContentValues v = values(item);
        return getWritableDatabase().insert("pantry", null, v);
    }
    public int updatePantry(PantryItem item) {
        return getWritableDatabase().update("pantry", values(item), "id=?", new String[]{String.valueOf(item.id)});
    }
    public int deletePantry(int id) {
        return getWritableDatabase().delete("pantry", "id=?", new String[]{String.valueOf(id)});
    }
    private ContentValues values(PantryItem item) {
        ContentValues v = new ContentValues();
        v.put("name", normalize(item.name)); v.put("quantity", item.quantity); v.put("unit", item.unit); v.put("expiry", item.expiry);
        return v;
    }

    public ArrayList<PantryItem> getPantry() {
        ArrayList<PantryItem> list = new ArrayList<>();
        Cursor c = getReadableDatabase().query("pantry", null, null, null, null, null, "name ASC");
        while (c.moveToNext()) list.add(new PantryItem(c.getInt(c.getColumnIndexOrThrow("id")),
                c.getString(c.getColumnIndexOrThrow("name")), c.getDouble(c.getColumnIndexOrThrow("quantity")),
                c.getString(c.getColumnIndexOrThrow("unit")), c.getString(c.getColumnIndexOrThrow("expiry"))));
        c.close(); return list;
    }

    public ArrayList<Recipe> getStrictMatches() {
        ArrayList<PantryItem> pantry = getPantry();
        ArrayList<Recipe> result = new ArrayList<>();
        Cursor c = getReadableDatabase().query("recipes", null, null, null, null, null, "name ASC");
        while (c.moveToNext()) {
            Recipe r = new Recipe(c.getInt(c.getColumnIndexOrThrow("id")), c.getString(c.getColumnIndexOrThrow("name")),
                    c.getString(c.getColumnIndexOrThrow("ingredients")), c.getString(c.getColumnIndexOrThrow("method")));
            if (canMake(r, pantry)) result.add(r);
        }
        c.close(); return result;
    }

    private boolean canMake(Recipe r, List<PantryItem> pantry) {
        for (String req : r.ingredients.split(",")) {
            String[] parts = req.split(":");
            String neededName = normalize(parts[0]);
            double neededQty = Double.parseDouble(parts[1]);
            PantryItem found = null;
            for (PantryItem p : pantry) {
                if (sameIngredient(p.name, neededName)) { found = p; break; }
            }
            if (found == null || found.quantity < neededQty) return false;
        }
        return true;
    }

    private boolean sameIngredient(String a, String b) {
        String x = normalize(a), y = normalize(b);
        return x.equals(y) || singular(x).equals(singular(y));
    }

    private String singular(String s) {
        if (s.endsWith("ies")) return s.substring(0, s.length()-3) + "y";
        if (s.endsWith("oes")) return s.substring(0, s.length()-2);
        if (s.endsWith("s") && !s.endsWith("ss")) return s.substring(0, s.length()-1);
        return s;
    }

    private String normalize(String s) {
        return s.trim().toLowerCase(Locale.US).replaceAll("\\s+", " ");
    }

    public Recipe getRecipe(int id) {
        Cursor c = getReadableDatabase().query("recipes", null, "id=?", new String[]{String.valueOf(id)}, null, null, null);
        Recipe r = null;
        if (c.moveToFirst()) r = new Recipe(c.getInt(c.getColumnIndexOrThrow("id")), c.getString(c.getColumnIndexOrThrow("name")),
                c.getString(c.getColumnIndexOrThrow("ingredients")), c.getString(c.getColumnIndexOrThrow("method")));
        c.close(); return r;
    }

    public void seedSamplePantry() {
        if (!getPantry().isEmpty()) return;
        String[][] p = {{"tomatoes","4","item"},{"onion","2","item"},{"egg","4","item"},{"bread","4","slices"},{"milk","500","ml"},
                {"chicken","300","g"},{"rice","300","g"},{"garlic","2","cloves"},{"lettuce","1","item"},{"cheese","3","slices"}};
        for (String[] a : p) addPantry(new PantryItem(0,a[0],Double.parseDouble(a[1]),a[2],""));
    }
}
