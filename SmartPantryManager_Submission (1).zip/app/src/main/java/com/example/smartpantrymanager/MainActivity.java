package com.example.smartpantrymanager;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.smartpantrymanager.adapter.PantryAdapter;
import com.example.smartpantrymanager.data.DatabaseHelper;
import com.example.smartpantrymanager.model.PantryItem;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private DatabaseHelper db; private ArrayList<PantryItem> pantry; private PantryAdapter adapter;
    @Override protected void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main); db=new DatabaseHelper(this);
        Button add=findViewById(R.id.btnAdd), suggest=findViewById(R.id.btnSuggest), settings=findViewById(R.id.btnSettings), seed=findViewById(R.id.btnSeed);
        RecyclerView rv=findViewById(R.id.recyclerPantry); rv.setLayoutManager(new LinearLayoutManager(this));
        pantry=db.getPantry(); adapter=new PantryAdapter(pantry,new PantryAdapter.Listener(){
            public void edit(PantryItem i){Intent x=new Intent(MainActivity.this,AddEditIngredientActivity.class);x.putExtra("id",i.id);startActivity(x);}
            public void delete(PantryItem i){db.deletePantry(i.id);load();}
        }); rv.setAdapter(adapter);
        add.setOnClickListener(v->startActivity(new Intent(this,AddEditIngredientActivity.class)));
        suggest.setOnClickListener(v->startActivity(new Intent(this,SuggestedRecipesActivity.class)));
        settings.setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));
        seed.setOnClickListener(v->{db.seedSamplePantry();load();Toast.makeText(this,"Sample pantry loaded.",Toast.LENGTH_SHORT).show();});
    }
    @Override protected void onResume(){super.onResume(); if(db!=null)load();}
    private void load(){pantry.clear();pantry.addAll(db.getPantry());adapter.notifyDataSetChanged();}
}
