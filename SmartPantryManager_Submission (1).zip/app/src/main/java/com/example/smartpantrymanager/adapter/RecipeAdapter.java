package com.example.smartpantrymanager.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.smartpantrymanager.R;
import com.example.smartpantrymanager.model.Recipe;
import java.util.List;

public class RecipeAdapter extends RecyclerView.Adapter<RecipeAdapter.Holder> {
    public interface Listener { void open(Recipe recipe); }
    private final List<Recipe> items; private final Listener listener;
    public RecipeAdapter(List<Recipe> items, Listener listener){this.items=items;this.listener=listener;}
    @NonNull @Override public Holder onCreateViewHolder(@NonNull ViewGroup p,int v){
        return new Holder(LayoutInflater.from(p.getContext()).inflate(R.layout.item_recipe,p,false));
    }
    @Override public void onBindViewHolder(@NonNull Holder h,int pos){
        Recipe r=items.get(pos); h.name.setText(r.name);
        h.summary.setText(r.ingredients.replace(",", " • ")); h.itemView.setOnClickListener(v->listener.open(r));
    }
    @Override public int getItemCount(){return items.size();}
    static class Holder extends RecyclerView.ViewHolder{
        TextView name,summary; Holder(View v){super(v);name=v.findViewById(R.id.txtRecipeName);summary=v.findViewById(R.id.txtRecipeSummary);}
    }
}
