package com.example.smartpantrymanager.model;

public class PantryItem {
    public int id;
    public String name;
    public double quantity;
    public String unit;
    public String expiry;

    public PantryItem(int id, String name, double quantity, String unit, String expiry) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.unit = unit;
        this.expiry = expiry;
    }
}
