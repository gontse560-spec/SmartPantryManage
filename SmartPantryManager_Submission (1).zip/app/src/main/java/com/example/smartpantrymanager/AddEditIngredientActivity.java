package com.example.smartpantrymanager;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.example.smartpantrymanager.data.DatabaseHelper;
import com.example.smartpantrymanager.model.PantryItem;

public class AddEditIngredientActivity extends AppCompatActivity {
    DatabaseHelper db; EditText name,qty,unit,expiry; int id=-1;
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);setContentView(R.layout.activity_add_edit);db=new DatabaseHelper(this);
        name=findViewById(R.id.edtName);qty=findViewById(R.id.edtQuantity);unit=findViewById(R.id.edtUnit);expiry=findViewById(R.id.edtExpiry);
        TextView title=findViewById(R.id.txtTitle); id=getIntent().getIntExtra("id",-1);
        if(id!=-1){title.setText("Edit Ingredient"); PantryItem item=null; for(PantryItem p:db.getPantry())if(p.id==id)item=p;
            if(item!=null){name.setText(item.name);qty.setText(String.valueOf(item.quantity));unit.setText(item.unit);expiry.setText(item.expiry);}}
        findViewById(R.id.btnSave).setOnClickListener(v->save());
        findViewById(R.id.btnCancel).setOnClickListener(v->finish());
    }
    private void save(){
        String n=name.getText().toString().trim(), q=qty.getText().toString().trim(), u=unit.getText().toString().trim(), e=expiry.getText().toString().trim();
        if(TextUtils.isEmpty(n)||TextUtils.isEmpty(q)||TextUtils.isEmpty(u)){Toast.makeText(this,"Name, quantity and unit are required.",Toast.LENGTH_LONG).show();return;}
        try{
            double quantity=Double.parseDouble(q); if(quantity<=0)throw new NumberFormatException();
            PantryItem item=new PantryItem(id,n,quantity,u,e); if(id==-1)db.addPantry(item);else db.updatePantry(item);
            Toast.makeText(this,"Ingredient saved.",Toast.LENGTH_SHORT).show();finish();
        }catch(Exception ex){Toast.makeText(this,"Enter a valid positive quantity.",Toast.LENGTH_LONG).show();}
    }
}
