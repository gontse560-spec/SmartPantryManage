package com.example.smartpantrymanager;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Switch;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);setContentView(R.layout.activity_settings);
        Switch s=findViewById(R.id.switchExpiry);SharedPreferences p=getSharedPreferences("settings",MODE_PRIVATE);
        s.setChecked(p.getBoolean("expiry",true));s.setOnCheckedChangeListener((v,checked)->p.edit().putBoolean("expiry",checked).apply());
        findViewById(R.id.btnSettingsBack).setOnClickListener(v->finish());
    }
}
