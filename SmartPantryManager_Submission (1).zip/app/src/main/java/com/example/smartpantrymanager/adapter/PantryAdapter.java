package com.example.smartpantrymanager.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.smartpantrymanager.R;
import com.example.smartpantrymanager.model.PantryItem;
import java.util.List;

public class PantryAdapter extends RecyclerView.Adapter<PantryAdapter.Holder> {
    public interface Listener { void edit(PantryItem item); void delete(PantryItem item); }
    private final List<PantryItem> items; private final Listener listener;
    public PantryAdapter(List<PantryItem> items, Listener listener) { this.items=items; this.listener=listener; }
    @NonNull @Override public Holder onCreateViewHolder(@NonNull ViewGroup p,int v) {
        return new Holder(LayoutInflater.from(p.getContext()).inflate(R.layout.item_pantry,p,false));
    }
    @Override public void onBindViewHolder(@NonNull Holder h,int pos) {
        PantryItem i=items.get(pos); h.name.setText(cap(i.name));
        h.details.setText(i.quantity+" "+i.unit+(i.expiry.isEmpty()?"":" • Expires "+i.expiry));
        h.edit.setOnClickListener(v->listener.edit(i)); h.delete.setOnClickListener(v->listener.delete(i));
    }
    @Override public int getItemCount(){return items.size();}
    private String cap(String s){return s.length()==0?s:s.substring(0,1).toUpperCase()+s.substring(1);}
    static class Holder extends RecyclerView.ViewHolder {
        TextView name,details; Button edit,delete;
        Holder(View v){super(v); name=v.findViewById(R.id.txtName); details=v.findViewById(R.id.txtDetails);
            edit=v.findViewById(R.id.btnEdit); delete=v.findViewById(R.id.btnDelete);}
    }
}
