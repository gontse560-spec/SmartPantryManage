# Smart Pantry Manager

Smart Pantry Manager is a Java Android application for tracking leftover ingredients and suggesting recipes that can be prepared strictly from the ingredients currently stored in the user's pantry.

## Main features
- SQLite persistent pantry database
- Create, Read, Update and Delete pantry ingredients
- RecyclerView with custom Adapter
- 20 seeded recipes
- Strict recipe matching using ingredient presence and required quantity
- Basic singular/plural normalization (for example tomato/tomatoes)
- Recipe detail screen
- Settings screen
- Input validation
- Intent-based navigation

## Database
SQLite was selected because the assignment permits local SQLite storage and the application is designed for a user's own pantry. It avoids unnecessary network configuration and demonstrates Android persistent storage.

## Run
1. Open the project in Android Studio.
2. Allow Gradle to sync.
3. Use an Android emulator or physical Android device.
4. Run the `app` configuration.
5. Press **Load Sample Pantry** for demonstration data.
6. Open **Suggestions** to test strict matching.

## Suggested demonstration
- Add an ingredient.
- Edit its quantity.
- Delete it.
- Reload the sample pantry.
- Open Suggested Recipes.
- Remove an ingredient from the pantry and return to Suggestions; a recipe requiring that ingredient should disappear.
- Close and reopen the app to demonstrate persistence.

## GitHub
Create a public repository named `SmartPantryManager` and push this project. The assignment requires meaningful incremental commits. This package includes a suggested commit sequence in `GITHUB_COMMIT_PLAN.md`.

## Academic integrity
The repository and report should be reviewed, tested, and explained by the student before submission.
