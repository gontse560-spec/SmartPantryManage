# GitHub Commit Plan

The assignment requires at least 10 meaningful incremental commits. Use the following sequence while developing/testing the project:

1. `Create Android Studio Java project structure`
2. `Add Gradle and AndroidX configuration`
3. `Add SQLite database helper`
4. `Seed recipe collection`
5. `Implement pantry CRUD`
6. `Add RecyclerView pantry adapter`
7. `Add strict recipe matching logic`
8. `Add recipe suggestions and detail screens`
9. `Add settings and input validation`
10. `Polish README and prepare submission`

After each genuine development step, commit and push to GitHub. Do not manufacture a history immediately before submission; the assignment explicitly says commit history is evidence of the development process.
